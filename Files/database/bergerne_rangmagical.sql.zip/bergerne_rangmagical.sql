-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 04, 2017 at 04:27 PM
-- Server version: 5.6.35
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bergerne_rangmagical`
--

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'members', 'General User');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

DROP TABLE IF EXISTS `tbl_admin`;
CREATE TABLE `tbl_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL DEFAULT '',
  `pass` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `status` int(11) DEFAULT NULL,
  `last_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `username`, `pass`, `email`, `title`, `status`, `last_modified`) VALUES
(1, 'dacadmin', 'a6881ada166f0ba853a2fcce4224ad15', 'customercare@bergernepal.com', 'BERGER PAINTS NEPAL - Rang Magical', NULL, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_coupon`
--

DROP TABLE IF EXISTS `tbl_coupon`;
CREATE TABLE `tbl_coupon` (
  `id` int(11) NOT NULL,
  `coupon_code` varchar(100) NOT NULL,
  `prize_image` varchar(255) NOT NULL,
  `prize_details` varchar(200) NOT NULL,
  `coupon_status` enum('0','1') NOT NULL DEFAULT '0',
  `user_id` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_coupon`
--

INSERT INTO `tbl_coupon` (`id`, `coupon_code`, `prize_image`, `prize_details`, `coupon_status`, `user_id`) VALUES
(1, '565765', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(2, '680023', 'personal_fan.png', 'Personal Fan', '0', ''),
(3, '339199', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(4, '980087', 'personal_fan.png', 'Personal Fan', '0', ''),
(5, '720947', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(6, '433847', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(7, '300006', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(8, '110382', 'personal_fan.png', 'Personal Fan', '0', ''),
(9, '558843', 'toaster.png', 'Toaster', '0', ''),
(10, '270535', 'personal_fan.png', 'Personal Fan', '0', ''),
(11, '525720', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(12, '111810', 'personal_fan.png', 'Personal Fan', '0', ''),
(13, '589413', 'toaster.png', 'Toaster', '0', ''),
(14, '136584', 'toaster.png', 'Toaster', '0', ''),
(15, '940344', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(16, '211291', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(17, '753192', 'toaster.png', 'Toaster', '0', ''),
(18, '639840', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(19, '158831', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(20, '583920', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(21, '265646', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(22, '151718', 'personal_fan.png', 'Personal Fan', '0', ''),
(23, '113293', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(24, '535003', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(25, '931802', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(26, '741134', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(27, '663351', 'personal_fan.png', 'Personal Fan', '0', ''),
(28, '340820', 'toaster.png', 'Toaster', '0', ''),
(29, '392373', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(30, '584387', 'toaster.png', 'Toaster', '0', ''),
(31, '418109', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(32, '659478', 'toaster.png', 'Toaster', '0', ''),
(33, '253698', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(34, '645828', 'toaster.png', 'Toaster', '0', ''),
(35, '311102', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(36, '205990', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(37, '641131', 'toaster.png', 'Toaster', '0', ''),
(38, '591171', 'toaster.png', 'Toaster', '0', ''),
(39, '721798', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(40, '292919', 'toaster.png', 'Toaster', '0', ''),
(41, '669778', 'personal_fan.png', 'Personal Fan', '0', ''),
(42, '874151', 'personal_fan.png', 'Personal Fan', '0', ''),
(43, '927682', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(44, '447415', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(45, '457192', 'personal_fan.png', 'Personal Fan', '0', ''),
(46, '257901', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(47, '987145', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(48, '337991', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(49, '963800', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(50, '608639', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(51, '157678', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(52, '951687', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(53, '272430', 'personal_fan.png', 'Personal Fan', '0', ''),
(54, '347164', 'personal_fan.png', 'Personal Fan', '0', ''),
(55, '414923', 'toaster.png', 'Toaster', '0', ''),
(56, '194042', 'toaster.png', 'Toaster', '0', ''),
(57, '622839', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(58, '628250', 'personal_fan.png', 'Personal Fan', '0', ''),
(59, '641928', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(60, '420471', 'toaster.png', 'Toaster', '0', ''),
(61, '108157', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(62, '653573', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(63, '147927', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(64, '175421', 'personal_fan.png', 'Personal Fan', '0', ''),
(65, '212609', 'personal_fan.png', 'Personal Fan', '0', ''),
(66, '411984', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(67, '423767', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(68, '854513', 'personal_fan.png', 'Personal Fan', '0', ''),
(69, '670190', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(70, '494107', 'toaster.png', 'Toaster', '0', ''),
(71, '805349', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(72, '454803', 'toaster.png', 'Toaster', '0', ''),
(73, '337716', 'toaster.png', 'Toaster', '0', ''),
(74, '429617', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(75, '788568', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(76, '238455', 'personal_fan.png', 'Personal Fan', '0', ''),
(77, '691613', 'toaster.png', 'Toaster', '0', ''),
(78, '643026', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(79, '859594', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(80, '403662', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(81, '117605', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(82, '638137', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(83, '597131', 'toaster.png', 'Toaster', '0', ''),
(84, '196652', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(85, '731439', 'personal_fan.png', 'Personal Fan', '0', ''),
(86, '480786', 'toaster.png', 'Toaster', '0', ''),
(87, '530197', 'personal_fan.png', 'Personal Fan', '0', ''),
(88, '376745', 'toaster.png', 'Toaster', '0', ''),
(89, '841989', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(90, '117221', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(91, '967068', 'toaster.png', 'Toaster', '0', ''),
(92, '453210', 'toaster.png', 'Toaster', '0', ''),
(93, '202392', 'toaster.png', 'Toaster', '0', ''),
(94, '652227', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(95, '137023', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(96, '953198', 'toaster.png', 'Toaster', '0', ''),
(97, '586474', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(98, '219860', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(99, '821115', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(100, '118154', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(101, '637286', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(102, '164379', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(103, '294595', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(104, '293991', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(105, '981021', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(106, '417916', 'toaster.png', 'Toaster', '0', ''),
(107, '629541', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(108, '193878', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(109, '631161', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(110, '110986', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(111, '852645', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(112, '166329', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(113, '843005', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(114, '990222', 'toaster.png', 'Toaster', '0', ''),
(115, '495837', 'toaster.png', 'Toaster', '0', ''),
(116, '133782', 'toaster.png', 'Toaster', '0', ''),
(117, '745913', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(118, '638989', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(119, '695184', 'personal_fan.png', 'Personal Fan', '0', ''),
(120, '941607', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(121, '992337', 'toaster.png', 'Toaster', '0', ''),
(122, '639511', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(123, '699386', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(124, '184155', 'personal_fan.png', 'Personal Fan', '0', ''),
(125, '324258', 'personal_fan.png', 'Personal Fan', '0', ''),
(126, '188192', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(127, '291052', 'toaster.png', 'Toaster', '0', ''),
(128, '769314', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(129, '126394', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(130, '336315', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(131, '302807', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(132, '872695', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(133, '621081', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(134, '734213', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(135, '115325', 'toaster.png', 'Toaster', '0', ''),
(136, '921035', 'personal_fan.png', 'Personal Fan', '0', ''),
(137, '863357', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(138, '985250', 'toaster.png', 'Toaster', '0', ''),
(139, '732208', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(140, '273336', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(141, '938394', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(142, '561892', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(143, '812353', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(144, '465789', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(145, '412313', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(146, '178717', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(147, '657089', 'personal_fan.png', 'Personal Fan', '0', ''),
(148, '343402', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(149, '845120', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(150, '669229', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(151, '270452', 'toaster.png', 'Toaster', '0', ''),
(152, '495343', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(153, '588479', 'toaster.png', 'Toaster', '0', ''),
(154, '784805', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(155, '132052', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(156, '745254', 'toaster.png', 'Toaster', '0', ''),
(157, '419207', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(158, '516683', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(159, '483917', 'toaster.png', 'Toaster', '0', ''),
(160, '147982', 'personal_fan.png', 'Personal Fan', '0', ''),
(161, '666592', 'toaster.png', 'Toaster', '0', ''),
(162, '145593', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(163, '213433', 'personal_fan.png', 'Personal Fan', '0', ''),
(164, '887692', 'toaster.png', 'Toaster', '0', ''),
(165, '877090', 'personal_fan.png', 'Personal Fan', '0', ''),
(166, '830316', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(167, '190911', 'toaster.png', 'Toaster', '0', ''),
(168, '994836', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(169, '264520', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(170, '905160', 'personal_fan.png', 'Personal Fan', '0', ''),
(171, '718640', 'personal_fan.png', 'Personal Fan', '0', ''),
(172, '980966', 'personal_fan.png', 'Personal Fan', '0', ''),
(173, '819604', 'personal_fan.png', 'Personal Fan', '0', ''),
(174, '506411', 'toaster.png', 'Toaster', '0', ''),
(175, '569473', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(176, '736712', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(177, '724627', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(178, '431951', 'personal_fan.png', 'Personal Fan', '0', ''),
(179, '801696', 'personal_fan.png', 'Personal Fan', '0', ''),
(180, '871295', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(181, '744073', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(182, '830535', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(183, '745419', 'toaster.png', 'Toaster', '0', ''),
(184, '201760', 'personal_fan.png', 'Personal Fan', '0', ''),
(185, '567578', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(186, '384765', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(187, '654782', 'personal_fan.png', 'Personal Fan', '0', ''),
(188, '400778', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(189, '821554', 'toaster.png', 'Toaster', '1', 'BRMG-K-000'),
(190, '815951', 'toaster.png', 'Toaster', '0', ''),
(191, '819934', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(192, '545935', 'personal_fan.png', 'Personal Fan', '0', ''),
(193, '491058', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(194, '618225', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(195, '436401', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(196, '782498', 'toaster.png', 'Toaster', '0', ''),
(197, '804855', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(198, '907604', 'personal_fan.png', 'Personal Fan', '0', ''),
(199, '328488', 'toaster.png', 'Toaster', '0', ''),
(200, '943090', 'personal_fan.png', 'Personal Fan', '0', ''),
(201, '349774', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(202, '934109', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(203, '884973', 'personal_fan.png', 'Personal Fan', '0', ''),
(204, '117907', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(205, '460598', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(206, '511575', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(207, '581118', 'toaster.png', 'Toaster', '0', ''),
(208, '277236', 'personal_fan.png', 'Personal Fan', '0', ''),
(209, '593917', 'personal_fan.png', 'Personal Fan', '0', ''),
(210, '784887', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(211, '170147', 'toaster.png', 'Toaster', '0', ''),
(212, '594000', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(213, '414154', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(214, '677633', 'toaster.png', 'Toaster', '0', ''),
(215, '875030', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(216, '724710', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(217, '831222', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(218, '531900', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(219, '613995', 'toaster.png', 'Toaster', '0', ''),
(220, '249935', 'toaster.png', 'Toaster', '0', ''),
(221, '106179', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(222, '388446', 'toaster.png', 'Toaster', '0', ''),
(223, '195800', 'personal_fan.png', 'Personal Fan', '0', ''),
(224, '294540', 'toaster.png', 'Toaster', '0', ''),
(225, '876156', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(226, '699743', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(227, '226782', 'toaster.png', 'Toaster', '0', ''),
(228, '413522', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(229, '383145', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(230, '883682', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(231, '427117', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(232, '462384', 'toaster.png', 'Toaster', '0', ''),
(233, '512399', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(234, '463400', 'toaster.png', 'Toaster', '0', ''),
(235, '755883', 'toaster.png', 'Toaster', '0', ''),
(236, '139633', 'toaster.png', 'Toaster', '0', ''),
(237, '750225', 'toaster.png', 'Toaster', '0', ''),
(238, '728884', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(239, '909747', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(240, '414346', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(241, '602404', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(242, '849871', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(243, '144686', 'toaster.png', 'Toaster', '0', ''),
(244, '183798', 'toaster.png', 'Toaster', '0', ''),
(245, '797192', 'personal_fan.png', 'Personal Fan', '0', ''),
(246, '699414', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(247, '933395', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(248, '395010', 'toaster.png', 'Toaster', '0', ''),
(249, '321813', 'toaster.png', 'Toaster', '0', ''),
(250, '352520', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(251, '486169', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(252, '898156', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(253, '370318', 'personal_fan.png', 'Personal Fan', '0', ''),
(254, '302450', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(255, '206512', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(256, '507427', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(257, '555438', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(258, '753851', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(259, '104119', 'personal_fan.png', 'Personal Fan', '0', ''),
(260, '724490', 'personal_fan.png', 'Personal Fan', '0', ''),
(261, '700320', 'personal_fan.png', 'Personal Fan', '0', ''),
(262, '249688', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(263, '809991', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(264, '169104', 'personal_fan.png', 'Personal Fan', '0', ''),
(265, '195745', 'toaster.png', 'Toaster', '0', ''),
(266, '162951', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(267, '919937', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(268, '626766', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(269, '532119', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(270, '120764', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(271, '220520', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(272, '117550', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(273, '478094', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(274, '598202', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(275, '420718', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(276, '233236', 'personal_fan.png', 'Personal Fan', '0', ''),
(277, '307943', 'toaster.png', 'Toaster', '0', ''),
(278, '618197', 'toaster.png', 'Toaster', '0', ''),
(279, '820016', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(280, '586639', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(281, '223760', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(282, '526516', 'toaster.png', 'Toaster', '0', ''),
(283, '113787', 'personal_fan.png', 'Personal Fan', '0', ''),
(284, '880853', 'personal_fan.png', 'Personal Fan', '0', ''),
(285, '593972', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(286, '444888', 'personal_fan.png', 'Personal Fan', '0', ''),
(287, '262680', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(288, '785189', 'toaster.png', 'Toaster', '0', ''),
(289, '138122', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(290, '399377', 'personal_fan.png', 'Personal Fan', '0', ''),
(291, '361199', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(292, '137655', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(293, '419784', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(294, '827459', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(295, '491799', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(296, '178277', 'toaster.png', 'Toaster', '0', ''),
(297, '310278', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(298, '357601', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(299, '785162', 'toaster.png', 'Toaster', '0', ''),
(300, '207363', 'toaster.png', 'Toaster', '0', ''),
(301, '464746', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(302, '223129', 'toaster.png', 'Toaster', '0', ''),
(303, '576037', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(304, '788980', 'toaster.png', 'Toaster', '0', ''),
(305, '959350', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(306, '878518', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(307, '639099', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(308, '353756', 'personal_fan.png', 'Personal Fan', '0', ''),
(309, '960586', 'toaster.png', 'Toaster', '0', ''),
(310, '428958', 'personal_fan.png', 'Personal Fan', '0', ''),
(311, '345132', 'toaster.png', 'Toaster', '0', ''),
(312, '602789', 'personal_fan.png', 'Personal Fan', '0', ''),
(313, '135211', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(314, '630337', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(315, '172290', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(316, '539920', 'personal_fan.png', 'Personal Fan', '0', ''),
(317, '429644', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(318, '228787', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(319, '225244', 'toaster.png', 'Toaster', '0', ''),
(320, '225079', 'personal_fan.png', 'Personal Fan', '0', ''),
(321, '144741', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(322, '596444', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(323, '975912', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(324, '481967', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(325, '521463', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(326, '359332', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(327, '631463', 'toaster.png', 'Toaster', '0', ''),
(328, '957565', 'personal_fan.png', 'Personal Fan', '0', ''),
(329, '518579', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(330, '171438', 'personal_fan.png', 'Personal Fan', '0', ''),
(331, '107305', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(332, '257598', 'personal_fan.png', 'Personal Fan', '0', ''),
(333, '522479', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(334, '532476', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(335, '412066', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(336, '968716', 'toaster.png', 'Toaster', '0', ''),
(337, '439175', 'toaster.png', 'Toaster', '0', ''),
(338, '970309', 'toaster.png', 'Toaster', '0', ''),
(339, '365676', 'toaster.png', 'Toaster', '0', ''),
(340, '434368', 'toaster.png', 'Toaster', '0', ''),
(341, '810375', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(342, '574856', 'toaster.png', 'Toaster', '0', ''),
(343, '603475', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(344, '322583', 'toaster.png', 'Toaster', '0', ''),
(345, '746875', 'personal_fan.png', 'Personal Fan', '0', ''),
(346, '494958', 'personal_fan.png', 'Personal Fan', '0', ''),
(347, '580267', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(348, '917904', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(349, '636709', 'personal_fan.png', 'Personal Fan', '0', ''),
(350, '270590', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(351, '843637', 'toaster.png', 'Toaster', '0', ''),
(352, '737509', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(353, '331838', 'toaster.png', 'Toaster', '0', ''),
(354, '417669', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(355, '394488', 'toaster.png', 'Toaster', '0', ''),
(356, '194125', 'toaster.png', 'Toaster', '0', ''),
(357, '211428', 'toaster.png', 'Toaster', '0', ''),
(358, '543325', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(359, '454144', 'personal_fan.png', 'Personal Fan', '0', ''),
(360, '491937', 'personal_fan.png', 'Personal Fan', '0', ''),
(361, '545523', 'toaster.png', 'Toaster', '0', ''),
(362, '323956', 'toaster.png', 'Toaster', '0', ''),
(363, '489739', 'toaster.png', 'Toaster', '0', ''),
(364, '560217', 'personal_fan.png', 'Personal Fan', '0', ''),
(365, '170367', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(366, '334036', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(367, '310827', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(368, '621878', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(369, '454034', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(370, '532366', 'toaster.png', 'Toaster', '0', ''),
(371, '555108', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(372, '318161', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(373, '464086', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(374, '523687', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(375, '174322', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(376, '869345', 'personal_fan.png', 'Personal Fan', '0', ''),
(377, '615643', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(378, '152322', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(379, '185665', 'toaster.png', 'Toaster', '0', ''),
(380, '235159', 'toaster.png', 'Toaster', '0', ''),
(381, '207116', 'personal_fan.png', 'Personal Fan', '0', ''),
(382, '685543', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(383, '702929', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(384, '533108', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(385, '531350', 'personal_fan.png', 'Personal Fan', '0', ''),
(386, '342028', 'toaster.png', 'Toaster', '0', ''),
(387, '162896', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(388, '621109', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(389, '490069', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(390, '441564', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(391, '637780', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(392, '246694', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(393, '873959', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(394, '565930', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(395, '231011', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(396, '833502', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(397, '919799', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(398, '964733', 'toaster.png', 'Toaster', '0', ''),
(399, '123757', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(400, '772528', 'toaster.png', 'Toaster', '0', ''),
(401, '540771', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(402, '598037', 'toaster.png', 'Toaster', '0', ''),
(403, '507290', 'personal_fan.png', 'Personal Fan', '0', ''),
(404, '632177', 'personal_fan.png', 'Personal Fan', '0', ''),
(405, '449365', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(406, '353839', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(407, '625668', 'personal_fan.png', 'Personal Fan', '0', ''),
(408, '317749', 'toaster.png', 'Toaster', '0', ''),
(409, '602926', 'toaster.png', 'Toaster', '0', ''),
(410, '430029', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(411, '269985', 'personal_fan.png', 'Personal Fan', '0', ''),
(412, '632781', 'toaster.png', 'Toaster', '0', ''),
(413, '999533', 'toaster.png', 'Toaster', '0', ''),
(414, '393032', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(415, '100054', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(416, '468481', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(417, '285147', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(418, '309811', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(419, '901205', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(420, '213269', 'toaster.png', 'Toaster', '0', ''),
(421, '570187', 'toaster.png', 'Toaster', '0', ''),
(422, '683703', 'toaster.png', 'Toaster', '0', ''),
(423, '328268', 'toaster.png', 'Toaster', '0', ''),
(424, '959844', 'toaster.png', 'Toaster', '0', ''),
(425, '148477', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(426, '748440', 'personal_fan.png', 'Personal Fan', '0', ''),
(427, '873464', 'personal_fan.png', 'Personal Fan', '0', ''),
(428, '343814', 'toaster.png', 'Toaster', '0', ''),
(429, '200744', 'toaster.png', 'Toaster', '0', ''),
(430, '409677', 'toaster.png', 'Toaster', '0', ''),
(431, '449832', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(432, '114694', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(433, '125543', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(434, '606195', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(435, '441043', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(436, '520117', 'toaster.png', 'Toaster', '0', ''),
(437, '892553', 'personal_fan.png', 'Personal Fan', '0', ''),
(438, '577740', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(439, '348840', 'toaster.png', 'Toaster', '0', ''),
(440, '444064', 'personal_fan.png', 'Personal Fan', '0', ''),
(441, '161523', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(442, '268475', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(443, '815264', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(444, '126422', 'toaster.png', 'Toaster', '0', ''),
(445, '460955', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(446, '807931', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(447, '590347', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(448, '105081', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(449, '962783', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(450, '284954', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(451, '626684', 'toaster.png', 'Toaster', '0', ''),
(452, '520611', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(453, '118869', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(454, '838034', 'toaster.png', 'Toaster', '0', ''),
(455, '189566', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(456, '201293', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(457, '155810', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(458, '874288', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(459, '499792', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(460, '564062', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(461, '867230', 'personal_fan.png', 'Personal Fan', '0', ''),
(462, '660604', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(463, '725753', 'toaster.png', 'Toaster', '0', ''),
(464, '867175', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(465, '663873', 'toaster.png', 'Toaster', '0', ''),
(466, '585183', 'toaster.png', 'Toaster', '0', ''),
(467, '412094', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(468, '249029', 'personal_fan.png', 'Personal Fan', '0', ''),
(469, '114144', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(470, '607595', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(471, '235186', 'toaster.png', 'Toaster', '0', ''),
(472, '351971', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(473, '456451', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(474, '140127', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(475, '108102', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(476, '821664', 'personal_fan.png', 'Personal Fan', '0', ''),
(477, '272457', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(478, '186791', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(479, '882226', 'personal_fan.png', 'Personal Fan', '0', ''),
(480, '580157', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(481, '825097', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(482, '584112', 'personal_fan.png', 'Personal Fan', '0', ''),
(483, '138589', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(484, '866708', 'personal_fan.png', 'Personal Fan', '0', ''),
(485, '302395', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(486, '556509', 'toaster.png', 'Toaster', '0', ''),
(487, '205468', 'toaster.png', 'Toaster', '0', ''),
(488, '853030', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(489, '339749', 'toaster.png', 'Toaster', '0', ''),
(490, '993380', 'personal_fan.png', 'Personal Fan', '0', ''),
(491, '192944', 'toaster.png', 'Toaster', '0', ''),
(492, '551455', 'toaster.png', 'Toaster', '0', ''),
(493, '688784', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(494, '738113', 'toaster.png', 'Toaster', '0', ''),
(495, '161578', 'personal_fan.png', 'Personal Fan', '0', ''),
(496, '931033', 'toaster.png', 'Toaster', '0', ''),
(497, '825756', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(498, '482681', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(499, '906176', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(500, '436126', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(501, '288388', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(502, '149960', 'personal_fan.png', 'Personal Fan', '0', ''),
(503, '585540', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(504, '250485', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(505, '304318', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(506, '339968', 'toaster.png', 'Toaster', '0', ''),
(507, '466503', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(508, '254797', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(509, '714190', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(510, '523934', 'toaster.png', 'Toaster', '0', ''),
(511, '234225', 'toaster.png', 'Toaster', '0', ''),
(512, '710125', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(513, '196624', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(514, '351477', 'toaster.png', 'Toaster', '0', ''),
(515, '927160', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(516, '192752', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(517, '372351', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(518, '624981', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(519, '195855', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(520, '902056', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(521, '147680', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(522, '931582', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(523, '423300', 'toaster.png', 'Toaster', '0', ''),
(524, '247216', 'toaster.png', 'Toaster', '0', ''),
(525, '430331', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(526, '296902', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(527, '682659', 'toaster.png', 'Toaster', '0', ''),
(528, '567330', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(529, '376910', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(530, '569995', 'toaster.png', 'Toaster', '0', ''),
(531, '753109', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(532, '416268', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(533, '377267', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(534, '751571', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(535, '975198', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(536, '940151', 'personal_fan.png', 'Personal Fan', '0', ''),
(537, '669174', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(538, '716085', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(539, '554394', 'toaster.png', 'Toaster', '0', ''),
(540, '502182', 'toaster.png', 'Toaster', '0', ''),
(541, '690542', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(542, '447222', 'personal_fan.png', 'Personal Fan', '0', ''),
(543, '306488', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(544, '780383', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(545, '517453', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(546, '407589', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(547, '927023', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(548, '160699', 'toaster.png', 'Toaster', '0', ''),
(549, '439477', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(550, '537448', 'personal_fan.png', 'Personal Fan', '0', ''),
(551, '338623', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(552, '912988', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(553, '606497', 'toaster.png', 'Toaster', '0', ''),
(554, '447442', 'toaster.png', 'Toaster', '0', ''),
(555, '719546', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(556, '777746', 'personal_fan.png', 'Personal Fan', '0', ''),
(557, '872256', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(558, '726467', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(559, '814825', 'toaster.png', 'Toaster', '0', ''),
(560, '910928', 'toaster.png', 'Toaster', '0', ''),
(561, '289761', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(562, '536596', 'toaster.png', 'Toaster', '0', ''),
(563, '554943', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(564, '115490', 'personal_fan.png', 'Personal Fan', '0', ''),
(565, '429342', 'toaster.png', 'Toaster', '0', ''),
(566, '489108', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(567, '712982', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(568, '606689', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(569, '789501', 'personal_fan.png', 'Personal Fan', '0', ''),
(570, '637258', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(571, '543215', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(572, '153750', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(573, '744128', 'personal_fan.png', 'Personal Fan', '0', ''),
(574, '780163', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(575, '895135', 'toaster.png', 'Toaster', '0', ''),
(576, '126257', 'toaster.png', 'Toaster', '0', ''),
(577, '553158', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(578, '384710', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(579, '161605', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(580, '903649', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(581, '729324', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(582, '329531', 'toaster.png', 'Toaster', '0', ''),
(583, '808151', 'toaster.png', 'Toaster', '0', ''),
(584, '954928', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(585, '319204', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(586, '283197', 'toaster.png', 'Toaster', '0', ''),
(587, '690460', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(588, '735449', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(589, '655001', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(590, '539370', 'toaster.png', 'Toaster', '0', ''),
(591, '179650', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(592, '718557', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(593, '105767', 'toaster.png', 'Toaster', '0', ''),
(594, '882611', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(595, '165451', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(596, '855282', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(597, '353701', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(598, '283856', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(599, '283691', 'toaster.png', 'Toaster', '0', ''),
(600, '487213', 'personal_fan.png', 'Personal Fan', '0', ''),
(601, '717898', 'toaster.png', 'Toaster', '0', ''),
(602, '573977', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(603, '839956', 'personal_fan.png', 'Personal Fan', '0', ''),
(604, '786206', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(605, '763189', 'toaster.png', 'Toaster', '0', ''),
(606, '146389', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(607, '825674', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(608, '703588', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(609, '514981', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(610, '126147', 'toaster.png', 'Toaster', '0', ''),
(611, '388198', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(612, '322390', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(613, '584140', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(614, '542199', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(615, '581311', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(616, '412039', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(617, '469250', 'toaster.png', 'Toaster', '0', ''),
(618, '571917', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(619, '142929', 'toaster.png', 'Toaster', '0', ''),
(620, '548873', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(621, '850228', 'personal_fan.png', 'Personal Fan', '0', ''),
(622, '518139', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(623, '251391', 'personal_fan.png', 'Personal Fan', '0', ''),
(624, '245623', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(625, '403002', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(626, '489547', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(627, '106152', 'personal_fan.png', 'Personal Fan', '0', ''),
(628, '187396', 'personal_fan.png', 'Personal Fan', '0', ''),
(629, '384545', 'toaster.png', 'Toaster', '0', ''),
(630, '236367', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(631, '688565', 'toaster.png', 'Toaster', '0', ''),
(632, '368423', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(633, '415719', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(634, '555630', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(635, '821499', 'personal_fan.png', 'Personal Fan', '0', ''),
(636, '718502', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(637, '622921', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(638, '400173', 'toaster.png', 'Toaster', '0', ''),
(639, '355075', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(640, '391687', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(641, '734652', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(642, '890603', 'toaster.png', 'Toaster', '0', ''),
(643, '369577', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(644, '332113', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(645, '525527', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(646, '605728', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(647, '567633', 'toaster.png', 'Toaster', '0', ''),
(648, '316650', 'personal_fan.png', 'Personal Fan', '0', ''),
(649, '817462', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(650, '505313', 'personal_fan.png', 'Personal Fan', '0', ''),
(651, '988299', 'toaster.png', 'Toaster', '0', ''),
(652, '659671', 'personal_fan.png', 'Personal Fan', '0', ''),
(653, '823339', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(654, '495068', 'toaster.png', 'Toaster', '0', ''),
(655, '348345', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(656, '456066', 'toaster.png', 'Toaster', '0', ''),
(657, '589797', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(658, '886209', 'toaster.png', 'Toaster', '0', ''),
(659, '341864', 'toaster.png', 'Toaster', '0', ''),
(660, '966244', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(661, '130651', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(662, '486224', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(663, '627618', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(664, '344281', 'toaster.png', 'Toaster', '0', ''),
(665, '796176', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(666, '451342', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(667, '919497', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(668, '992584', 'toaster.png', 'Toaster', '0', ''),
(669, '688619', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(670, '535140', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(671, '298385', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(672, '648849', 'toaster.png', 'Toaster', '0', ''),
(673, '645223', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(674, '523056', 'toaster.png', 'Toaster', '0', ''),
(675, '302120', 'toaster.png', 'Toaster', '0', ''),
(676, '493255', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(677, '198025', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(678, '397317', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(679, '317172', 'personal_fan.png', 'Personal Fan', '0', ''),
(680, '893185', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(681, '959295', 'toaster.png', 'Toaster', '0', ''),
(682, '431018', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(683, '146911', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(684, '458538', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(685, '197888', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(686, '435137', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(687, '610617', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(688, '979483', 'toaster.png', 'Toaster', '0', ''),
(689, '133837', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(690, '416900', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(691, '174459', 'toaster.png', 'Toaster', '0', ''),
(692, '141857', 'toaster.png', 'Toaster', '0', ''),
(693, '965859', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(694, '594110', 'toaster.png', 'Toaster', '0', ''),
(695, '241641', 'toaster.png', 'Toaster', '0', ''),
(696, '197283', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(697, '163418', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(698, '135897', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(699, '201513', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(700, '430303', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(701, '270150', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(702, '640829', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(703, '357546', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(704, '918069', 'toaster.png', 'Toaster', '0', ''),
(705, '627673', 'personal_fan.png', 'Personal Fan', '0', ''),
(706, '262707', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(707, '966903', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(708, '590924', 'personal_fan.png', 'Personal Fan', '0', ''),
(709, '842868', 'toaster.png', 'Toaster', '0', ''),
(710, '926171', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(711, '441098', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(712, '323818', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(713, '671453', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(714, '250952', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(715, '991265', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(716, '447799', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(717, '426815', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(718, '120791', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(719, '259741', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(720, '650057', 'toaster.png', 'Toaster', '0', ''),
(721, '409924', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(722, '122796', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(723, '780493', 'personal_fan.png', 'Personal Fan', '0', ''),
(724, '705264', 'personal_fan.png', 'Personal Fan', '0', ''),
(725, '768820', 'toaster.png', 'Toaster', '0', ''),
(726, '593203', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(727, '153393', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(728, '698095', 'toaster.png', 'Toaster', '0', ''),
(729, '929055', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(730, '143121', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(731, '386166', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(732, '966024', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(733, '155618', 'personal_fan.png', 'Personal Fan', '0', ''),
(734, '675656', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(735, '716497', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(736, '509982', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(737, '701638', 'toaster.png', 'Toaster', '0', ''),
(738, '740447', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(739, '359744', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(740, '646542', 'toaster.png', 'Toaster', '0', ''),
(741, '690075', 'toaster.png', 'Toaster', '0', ''),
(742, '132025', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(743, '221838', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(744, '772967', 'toaster.png', 'Toaster', '0', ''),
(745, '476583', 'toaster.png', 'Toaster', '0', ''),
(746, '952621', 'toaster.png', 'Toaster', '0', ''),
(747, '427062', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(748, '604766', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(749, '682247', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(750, '417422', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(751, '272540', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(752, '770001', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(753, '719903', 'toaster.png', 'Toaster', '0', ''),
(754, '675848', 'personal_fan.png', 'Personal Fan', '0', ''),
(755, '258807', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(756, '542364', 'toaster.png', 'Toaster', '0', ''),
(757, '516766', 'personal_fan.png', 'Personal Fan', '0', ''),
(758, '893981', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(759, '620285', 'personal_fan.png', 'Personal Fan', '0', ''),
(760, '944876', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(761, '543188', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(762, '510696', 'toaster.png', 'Toaster', '0', ''),
(763, '539974', 'personal_fan.png', 'Personal Fan', '0', ''),
(764, '244635', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(765, '698617', 'toaster.png', 'Toaster', '0', ''),
(766, '190197', 'toaster.png', 'Toaster', '0', ''),
(767, '293798', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(768, '946304', 'personal_fan.png', 'Personal Fan', '0', ''),
(769, '620779', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(770, '834985', 'toaster.png', 'Toaster', '0', ''),
(771, '480648', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(772, '300115', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(773, '459060', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(774, '388830', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(775, '699304', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(776, '393884', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(777, '404788', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(778, '822570', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(779, '719573', 'toaster.png', 'Toaster', '0', ''),
(780, '384326', 'personal_fan.png', 'Personal Fan', '0', ''),
(781, '882254', 'toaster.png', 'Toaster', '0', ''),
(782, '367791', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(783, '117935', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(784, '308602', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(785, '882583', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(786, '924606', 'personal_fan.png', 'Personal Fan', '0', ''),
(787, '878710', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(788, '459362', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(789, '464718', 'personal_fan.png', 'Personal Fan', '0', ''),
(790, '597790', 'toaster.png', 'Toaster', '0', ''),
(791, '458401', 'samsung_mobile.png', 'Samsung Mobile', '0', ''),
(792, '552636', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(793, '530059', 'personal_fan.png', 'Personal Fan', '0', ''),
(794, '223019', 'sandwich_maker.png', 'Sandwich Maker', '0', ''),
(795, '400311', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(796, '701309', 'toaster.png', 'Toaster', '0', ''),
(797, '220327', 'toaster.png', 'Toaster', '0', ''),
(798, '463235', 'electric_kettle.png', 'Electric Kettle', '0', ''),
(799, '557223', 'personal_fan.png', 'Personal Fan', '0', ''),
(800, '792083', 'electric_kettle.png', 'Electric Kettle', '0', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pattern`
--

DROP TABLE IF EXISTS `tbl_pattern`;
CREATE TABLE `tbl_pattern` (
  `id` int(11) NOT NULL,
  `shades` varchar(100) NOT NULL,
  `pattern` varchar(100) NOT NULL,
  `display` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pattern`
--

INSERT INTO `tbl_pattern` (`id`, `shades`, `pattern`, `display`) VALUES
(1, 'Metallica', 'metallica_curves.jpg', '1'),
(2, 'Metallica', 'metallica_blossoms_7.jpg', '1'),
(3, 'Metallica', 'metallica_beauty_queen.jpg', '1'),
(4, 'Metallica', 'metallica_blossoms_4.jpg', '0'),
(5, 'Metallica', 'metallica_blossoms_3.jpg', '1'),
(6, 'Metallica', 'metallica_silver_fire_rich_silk.jpg', '1'),
(7, 'Metallica', 'metallica_inferno_2.jpg', '1'),
(8, 'Metallica', 'metallica_inferno_1.jpg', '1'),
(9, 'Metallica', 'metallica_silver_fire_moroccan_sand.jpg', '1'),
(10, 'Metallica', 'metallica_inferno_6.jpg', '1'),
(11, 'Metallica', 'metallica_haiku_5.jpg', '1'),
(12, 'Metallica', 'metallica_haiku_2.jpg', '0'),
(13, 'Metallica', 'metallica_blossoms_6.jpg', '1'),
(14, 'Metallica', 'metallica_blossoms_1.jpg', '0'),
(15, 'Metallica', 'metallica_inferno_4.jpg', '1'),
(16, 'Metallica', 'metallica_blossoms_5.jpg', '1'),
(17, 'Metallica', 'metallica_haiku_6.jpg', '1'),
(18, 'Metallica', 'metallica_silver_fire_gently_raining.jpg', '1'),
(19, 'Metallica', 'metallica_inferno_3.jpg', '1'),
(20, 'Metallica', 'metallica_haiku_3.jpg', '1'),
(21, 'Metallica', 'metallica_silver_fire_boston_brick.jpg', '0'),
(22, 'Metallica', 'metallica_blossoms_2.jpg', '1'),
(23, 'Metallica', 'metallica_haiku_1.jpg', '1'),
(24, 'Metallica', 'metallica_haiku_4.jpg', '1'),
(25, 'Metallica', 'metallica_silver_caramel_mist.jpg', '0'),
(26, 'Metallica', 'metallica_inferno_5.jpg', '1'),
(27, 'Metallica', 'metallica_blossoms_8.jpg', '1'),
(28, 'Metallica', 'metallica_silver_bright_wine.jpg', '1'),
(29, 'Non - metallica', 'rush.jpg', '1'),
(30, 'Non - metallica', 'maze_crush1.jpg', '1'),
(31, 'Non - metallica', 'maze_nova_first_crocus.jpg', '1'),
(32, 'Non - metallica', 'maze_nova_daisy_heart.jpg', '1'),
(33, 'Non - metallica', 'maze_crush2.jpg', '1'),
(34, 'Non - metallica', 'maze_nova_coral_beige.jpg', '0'),
(35, 'Non - metallica', 'maze_autumn_spiced_pear.jpg', '1'),
(36, 'Non - metallica', 'maze_moonrock_atta_girl.jpg', '1'),
(37, 'Non - metallica', 'maze_nova_joyful_morning.jpg', '1'),
(38, 'Non - metallica', 'maze_moonrock_orange_spice.jpg', '1'),
(39, 'Non - metallica', 'maze_moonrock_gentle_dawn.jpg', '1'),
(40, 'Non - metallica', 'maze_autumn_charm_school.jpg', '1'),
(41, 'Non - metallica', 'maze_autumn_astronaut.jpg', '1'),
(42, 'Non - metallica', 'maze_autumn_good_fortune.jpg', '1'),
(43, 'Non - metallica', 'maze_flora4_midnight_mauve.jpg', '1'),
(44, 'Non - metallica', 'maze_nova_currant_craze.jpg', '1'),
(45, 'Non - metallica', 'maze_crush.jpg', '0'),
(46, 'Non - metallica', 'maze_flora_coral_sunset.jpg', '1'),
(47, 'Non - metallica', 'maze_autumn_moroccan_velvet.jpg', '1'),
(48, 'Non - metallica', 'maze_flora_ventana.jpg', '1'),
(49, 'Non - metallica', 'maze_flora_wild_grass.jpg', '0'),
(50, 'Non - metallica', 'maze_moonrock_seira_grande.jpg', '0'),
(51, 'Non - metallica', 'maze_autumn_banana_palm.jpg', '1'),
(52, 'Non - metallica', 'maze_crush5.jpg', '1'),
(53, 'Non - metallica', 'maze_crush6.jpg', '1'),
(54, 'Non - metallica', 'maze_moonrock_clean_khaki.jpg', '0'),
(55, 'Non - metallica', 'maze_nova_heritage_garden.jpg', '1'),
(56, 'Non - metallica', 'maze_crush3.jpg', '1'),
(57, 'Non - metallica', 'maze_flora_galleon_gold.jpg', '1'),
(58, 'Non - metallica', 'maze_flora_scuba_blue.jpg', '1'),
(59, 'Non - metallica', 'maze_moonrock_enchanted_evening.jpg', '1'),
(60, 'Non - metallica', 'spatulato.jpg', '1'),
(61, 'Non - metallica', 'twirl.jpg', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_photo`
--

DROP TABLE IF EXISTS `tbl_photo`;
CREATE TABLE `tbl_photo` (
  `id` int(11) NOT NULL,
  `serial_number` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `uploaded_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `imagepath` text NOT NULL,
  `imagename` text NOT NULL,
  `likes` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_photo`
--

INSERT INTO `tbl_photo` (`id`, `serial_number`, `user_id`, `uploaded_date`, `imagepath`, `imagename`, `likes`) VALUES
(1, 1, 'BRMG-K-000', '2017-09-03 18:15:00', 'uploads/2017/kathmandu/', 'BRMG-K-000.jpg', 0),
(2, 1, 'BRMG-COM-000', '2017-09-03 18:15:00', 'uploads/2017/commercial/', 'BRMG-COM-000.jpeg', 0),
(3, 1, 'BRMG-P-000', '2017-09-03 18:15:00', 'uploads/2017/pokhara/', 'BRMG-P-000.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_regions`
--

DROP TABLE IF EXISTS `tbl_regions`;
CREATE TABLE `tbl_regions` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `city_number` int(11) NOT NULL,
  `region` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_regions`
--

INSERT INTO `tbl_regions` (`id`, `parent_id`, `city_number`, `region`) VALUES
(1, 0, 0, 'Kathmandu'),
(2, 0, 0, 'Pokhara'),
(3, 0, 0, 'Eastern'),
(4, 0, 0, 'Central'),
(5, 0, 0, 'Western'),
(6, 1, 1, 'Dhading'),
(7, 1, 1, 'Trisuli'),
(8, 1, 1, 'Nuwakot'),
(9, 1, 2, 'Banepa'),
(10, 2, 3, 'Aabu Khaireni'),
(11, 2, 3, 'Damauli'),
(12, 2, 4, 'Dule Gauda'),
(13, 2, 4, 'Khairenitar'),
(14, 2, 5, 'lekhnath'),
(15, 2, 6, 'Parbat'),
(16, 2, 6, 'Baglung'),
(17, 2, 7, 'Syanja'),
(18, 2, 7, 'Waling'),
(19, 3, 8, 'Birtamod'),
(20, 3, 9, 'Damak'),
(21, 3, 10, 'Inaruwa'),
(22, 3, 10, 'Jhumka'),
(23, 3, 10, 'Dubi'),
(24, 3, 11, 'Lahan'),
(25, 3, 11, 'Rajbiraj'),
(26, 3, 12, 'Gaighat'),
(27, 4, 13, 'Janakpur'),
(28, 4, 14, 'Bardibas'),
(29, 4, 14, 'sindhuli'),
(30, 4, 14, 'Laalbandi'),
(31, 4, 15, 'Birgunj'),
(32, 4, 16, 'Hetauda'),
(33, 4, 17, 'Tandi'),
(34, 4, 17, 'parsa'),
(35, 4, 18, 'Gitanagar'),
(36, 4, 18, 'Rampur'),
(37, 4, 18, 'Saradhanagar'),
(38, 4, 18, 'shiva Nagar'),
(39, 4, 18, 'Maadi'),
(40, 4, 19, 'Gaidakot'),
(41, 4, 20, 'Rajahar'),
(42, 4, 20, 'Kawasoti'),
(43, 4, 20, 'Dumkibas'),
(44, 4, 21, 'Bardaghat'),
(45, 4, 21, 'Sunawal'),
(46, 4, 22, 'Gulmi'),
(47, 4, 22, 'Palpa'),
(48, 4, 22, 'Arghakhachi'),
(49, 5, 23, 'Bhaluwang'),
(50, 5, 23, 'Sisneha'),
(51, 5, 23, 'Lamahi'),
(52, 5, 24, 'Ghorahi'),
(53, 5, 24, 'Tulsipur'),
(54, 5, 25, 'Kohalpur'),
(55, 5, 26, 'Nepalgunj'),
(56, 5, 27, 'Surkhet'),
(57, 5, 28, 'Lamki'),
(58, 5, 28, 'Tikapur'),
(59, 5, 29, 'Dhangadi'),
(60, 5, 29, 'Attariya'),
(61, 5, 30, 'Mahendranagar'),
(62, 1, 0, 'Kathmandu'),
(63, 2, 0, 'Pokhara'),
(64, 3, 0, 'Eastern'),
(65, 4, 0, 'Central'),
(66, 5, 0, 'Western');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `fbid` varchar(50) NOT NULL,
  `like_count` int(11) NOT NULL,
  `like_count_update` int(11) NOT NULL DEFAULT '0',
  `registration_number` varchar(50) NOT NULL,
  `registration_date` date NOT NULL,
  `full_name` text NOT NULL,
  `passcode` varchar(25) NOT NULL,
  `sub_region` varchar(255) NOT NULL,
  `main_region` varchar(255) NOT NULL,
  `coupon_qty` varchar(10) NOT NULL,
  `coupon_no` varchar(255) NOT NULL,
  `shade` varchar(255) NOT NULL,
  `pattern` varchar(255) NOT NULL,
  `availability` enum('Available','Not Available') NOT NULL DEFAULT 'Not Available',
  `medium` enum('','facebook','website','admin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `fbid`, `like_count`, `like_count_update`, `registration_number`, `registration_date`, `full_name`, `passcode`, `sub_region`, `main_region`, `coupon_qty`, `coupon_no`, `shade`, `pattern`, `availability`, `medium`) VALUES
(1, '', 0, 0, 'BRMG-K-000', '2017-09-04', 'Sanjeev Singh', '12345', 'Banepa', 'Kathmandu', '3', 'xp10257, xp10258, xp10259, ', 'Non- Metallica', 'maze_crush3.jpg', 'Not Available', 'website'),
(2, '', 0, 0, 'BRMG-COM-000', '2017-09-04', 'Amol Shrestha', '12345', '', 'Commercial', '3', '12345, 654321, 78965, ', 'Metallica', 'metallica_blossoms_6.jpg', 'Not Available', 'website'),
(3, '', 0, 0, 'BRMG-P-000', '2017-09-04', 'Pankaj Bhattarai', '12345', 'Dule Gauda', 'Pokhara', '5', 'xp10257, xp10258, 123456, 659874, 12585, ', 'Metallica', 'metallica_blossoms_3.jpg', 'Not Available', 'website'),
(4, '', 0, 0, 'BRMG-W-000', '2017-09-04', '', '12345', '', '', '', '', '', '', 'Not Available', 'admin'),
(5, '', 0, 0, 'BRMG-E-000', '2017-09-04', '', '12345', '', '', '', '', '', '', 'Not Available', 'admin'),
(6, '', 0, 0, 'BRMG-C-000', '2017-09-04', '', '12345', '', '', '', '', '', '', 'Not Available', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) UNSIGNED DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) UNSIGNED NOT NULL,
  `last_login` int(11) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) UNSIGNED DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `modules` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`, `modules`) VALUES
(1, '127.0.0.1', 'administrator', '$2y$08$S9MEev7kTTM5MAnU5wXjauyrdut7tr9pVWeQSpkDjckFw17.7v2rK', '', 'admin@bergernepal.com', NULL, NULL, NULL, 'tdHS9cMdzmHvmJbXsmuuhe', 1268889823, 1504513120, 1, 'Berger Paints', 'Nepal', 'Berger Paints Nepal', '9851237969', '');

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

DROP TABLE IF EXISTS `users_groups`;
CREATE TABLE `users_groups` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `group_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(92, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_coupon`
--
ALTER TABLE `tbl_coupon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_pattern`
--
ALTER TABLE `tbl_pattern`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_photo`
--
ALTER TABLE `tbl_photo`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `tbl_regions`
--
ALTER TABLE `tbl_regions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_coupon`
--
ALTER TABLE `tbl_coupon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=801;
--
-- AUTO_INCREMENT for table `tbl_pattern`
--
ALTER TABLE `tbl_pattern`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;
--
-- AUTO_INCREMENT for table `tbl_photo`
--
ALTER TABLE `tbl_photo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_regions`
--
ALTER TABLE `tbl_regions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;
--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
